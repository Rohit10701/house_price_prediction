clc
clear all
close all
%to load data
load('House_data_final.mat');
%feedforward used to create neural network
net=feedforwardnet([4],'trainlm')
net=train(net,x_input,target)%here we are training the network using data
%now we are going to extract the unknown test data for checking 
%the mean error
[net,tr]=train(net,x_input,target);%tr: training recod
y=net(x_input);
target_test=target(:,tr.testInd);%from this we are finding the 
%test data from training record
y_test=y(:,tr.testInd);
%finding the error between target_test and y_test
error=abs(target_test-y_test);
%finding mean error
error_final=mean(error)
[m,n]=size(target_test);

count=0;
for i=1:n
    if error(i)<=error_final
        count=count+1;
    end
end
score=((count*100)/n);
statement='The Prediction score is %i\n';
fprintf(statement,score);
%plotting target_test and y_test
plot(target_test,'g');
hold on
plot(y_test,'b');
title('Visual Comparison between target test and y test')
legend('target test','y test')
figure(2)
plot(error);%Plotting error graph
title('Error Graph')
